const gulp = require('gulp');
const babel = require('gulp-babel');

function dealJs() {
    gulp.src('./script.js')
        .pipe(babel({
            "presets": ["env"]
        }))
        .pipe(gulp.dest('dist'))
};

gulp.watch('./*.js', dealJs);
gulp.task('default', function () {
    dealJs();
})
