import color from "color";

window.color = color;
