CanvasRenderingContext2D.prototype.sector = function (x, y, radius, sDeg, eDeg) {
    // 初始保存  
    this.save();
    // 位移到目标点  
    this.translate(x, y);
    this.beginPath();
    // 画出圆弧  
    this.arc(0, 0, radius, sDeg, eDeg);
    // 再次保存以备旋转  
    this.save();
    // 旋转至起始角度  
    this.rotate(eDeg);
    // 移动到终点，准备连接终点与圆心  
    this.moveTo(radius, 0);
    // 连接到圆心  
    this.lineTo(0, 0);
    // 还原  
    this.restore();
    // 旋转至起点角度  
    this.rotate(sDeg);
    // 从圆心连接到起点  
    this.lineTo(radius, 0);
    this.closePath();
    // 还原到最初保存的状态  
    this.restore();
    return this;
};
class ColorPicker {
    constructor(param) {
        let initParam = {
            dom: ".colorPicker",
            colorPanelDom: ".colorPicker-colorPanel",
            colorCanvasDom: ".colorPicker-colorCanvas",
        };
        this.cpParam = $.extend(true, initParam, param);
        this.cpDom = this.cpParam.dom;
        this.cpPanelDom = this.cpParam.colorPanelDom;
        this.colorCanvasDom = this.cpParam.colorCanvasDom;
    }

    initColorPanel() {
        this.canvasDom = $(this.cpDom).find(this.colorCanvasDom);
        this.ctx = this.canvasDom[0].getContext('2d');


        ctx.clearRect(0, 0, 400, 400);
        ctx.restore();
        ctx.save();

        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.beginPath();
        ctx.arc(0, 0, this.radius + 29, 0, 2 * Math.PI, false);
        ctx.strokeStyle = "rgba(0,0,0,0.1)";
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.restore();
        ctx.save();
    }
}
